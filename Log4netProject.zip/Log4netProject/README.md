# GitPractice
Git command is imfortant to learn. 
