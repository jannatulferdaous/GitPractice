﻿using log4net;
using log4net.Config;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace helloWorld
{
    using log4net;
    using log4net.Config;
    using System.IO;
    using System.Reflection;

    class Program
    {
        private static readonly ILog log = LogManager.GetLogger(typeof(Program));

        static void Main(string[] args)
        {
            log.Debug("Application is starting...");
            Console.WriteLine("Hello, World!");
            log.Info("Application end.");

            // Your code...
        }
    }

}
